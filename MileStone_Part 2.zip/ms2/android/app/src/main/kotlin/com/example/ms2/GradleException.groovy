package com.example.ms2

class GradleException {
    GradleException(java.lang.String string) {

    }
}

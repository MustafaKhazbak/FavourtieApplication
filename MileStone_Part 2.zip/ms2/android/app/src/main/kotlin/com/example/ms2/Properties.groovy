package com.example.ms2

class Properties {
}

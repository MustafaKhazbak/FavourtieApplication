import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:ms2/models/Location.dart';
import 'package:url_launcher/url_launcher.dart';
import 'data/LocationsAll.dart';
import 'package:ms2/Houda.dart';
import 'package:firebase_core/firebase_core.dart';
void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(MyApp());
}



class MyApp extends StatelessWidget {
  // This widget is the root
  // of your application.
  @override
  Widget build(BuildContext context) {
    return new MaterialApp(
        title: "Favorite Location App",
        theme: new ThemeData(
          primarySwatch: Colors.amber,
        ),
        debugShowCheckedModeBanner: false,
        home: new MyAppPage()
    );

  }
}
class MyAppPage extends StatelessWidget {
  Location l=new Location();
  MyAppPage({this.l});
  final Future<FirebaseApp> _initialization = Firebase.initializeApp();
  @override
  Widget build(BuildContext context) {

    return FutureBuilder(
        future: _initialization,
        builder: (context, snapshot) {
          return
            Scaffold(
                floatingActionButton: FloatingActionButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => ButtonRoute()),
                    );
                  },
                  child: const Icon(Icons.add),
                  backgroundColor: Colors.amber,
                ),
                appBar: AppBar(
                    title: Text("Favorite Location Application")
                ),
                body: StreamBuilder(
                    stream: FirebaseFirestore.instance.collection('Aly')
                        .snapshots(),
                    builder: (BuildContext context,
                        AsyncSnapshot<QuerySnapshot> snapshot) {
                      if (!snapshot.hasData) {
                        return Center(
                          child: CircularProgressIndicator(),
                        );
                      }

                      return new ListView(
                        children: snapshot.data.docs.map((
                            DocumentSnapshot document) {
                          Map<String, dynamic> data = document.data() as Map<
                              String,
                              dynamic>;
                          String id=data['id'].toString();
                          return Card(
                            child: new InkWell(
                              onTap: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(builder: (context) =>
                                      SecondRoute(i:id)),
                                );
                              },

                              child: Column(

                                  children: [
                                    Image.network(data['imageUrl']),
                                    Text(data['name']),
                                    Text(data['theme'],
                                        style: TextStyle(color: Colors.grey)),

                                  ]
                              ),
                            ),
                          );
                        }).toList(),
                      );
                    }
                ));
        }
    );

  }
}

class SecondRoute extends StatelessWidget {
  final CollectionReference Aly = FirebaseFirestore.instance.collection('Aly');

  String i;
  SecondRoute({this.i}){}
  @override
  Widget build(BuildContext context) {
    return StreamBuilder(
        stream: Aly.doc(i)
            .snapshots(),
        builder: (BuildContext context,
            AsyncSnapshot<DocumentSnapshot> snapshot) {

          if (!snapshot.hasData) {
            return Center(
              child: CircularProgressIndicator(),
            );
          }
          return Scaffold(
              floatingActionButton:FloatingActionButton(
                child: Icon(Icons.location_on),
                onPressed: () {
                  launch(snapshot.data.get('locationUrl'));

                },
              ),
              appBar: AppBar(
                title: Text("Details"),
              ),
              body:Column(
                  children: [
                    Text(snapshot.data.get('name'),
                        style: TextStyle(fontSize: 30.0, fontWeight: FontWeight.bold,
                            fontStyle: FontStyle.italic, fontFamily: 'sans-serif')),
                    Padding(
                      padding: const
                      EdgeInsets.symmetric(vertical: 5.0),
                    ),
                    Container(height: 240, width: 380,
                        child: Image.network(snapshot.data.get('imageUrl'))),
                    Padding(
                      padding: const
                      EdgeInsets.symmetric(vertical: 5.0),
                    ),
                    Text(snapshot.data.get('description'),
                        style: TextStyle(fontSize: 14.0, fontFamily: 'sans-serif')),


                  ]
              )
          );
        }

    );

  }

}

class ButtonRoute extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.amber,
        title: Text("Form"),
      ),

      body: MyFormPage(),
    );
  }
}
class MyFormPage extends StatefulWidget {
  MyFormPage({Key key, this.title,}) : super(key: key);
  final String title;
  MyFormPageState createState() {
    return MyFormPageState();

  }
}

class MyFormPageState extends State<MyFormPage> {
  int i =LocationsAll.listobj.length;
  String name;
  String theme;
  String description;
  String imageUrl;
  String locationUrl;
  Location l=new Location();

  final key = GlobalKey<FormState>();
  final myController = TextEditingController();
  Widget build(BuildContext context) {
    return Form(
      key: key,

      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          TextFormField(
              decoration: const InputDecoration(
                icon: const Icon(Icons.location_city),
                hintText: 'Enter location name',
                labelText: 'Location name',

              ),
              validator: (value) {
                if (value.isEmpty) {
                  return 'Please enter Location name';
                }
                else{
                  l.name =value;
                  l.id=i+1;

                }
                return null;
              }),
          TextFormField(
            decoration: const InputDecoration(
              icon: const Icon(Icons.theaters),
              hintText: 'Enter Theme',
              labelText: 'Theme',
            ),
            validator: (value) {
              if (value.isEmpty) {
                return 'Please enter theme';
              }
              else{
                l.theme=value;
              }
              return null;
            },
          ),
          TextFormField(
              decoration: const InputDecoration(
                icon: const Icon(Icons.description),
                hintText: 'Enter full description',
                labelText: 'Full description',
              ),
              validator: (value) {
                if (value.isEmpty) {
                  return 'Please enter full description';
                }
                else{
                  l.description=value;
                }
                return null;
              }),
          TextFormField(
              decoration: const InputDecoration(
                icon: const Icon(Icons.image),
                hintText: 'Enter image URL',
                labelText: 'Image URL',
              ),
              validator: (value) {
                if (value.isEmpty) {
                  return 'Please enter image URL';
                }
                else{
                  l.imageUrl=value;
                }
                return null;
              }),
          TextFormField(
              decoration: const InputDecoration(
                icon: const Icon(Icons.location_city),
                hintText: 'Enter location URL',
                labelText: 'Location URL',
              ),
              validator: (value) {
                if (value.isEmpty) {
                  return 'Please enter Location URL';
                }
                else{
                  l.locationUrl=value;
                }
                return null;
              }),

          new Container(
              padding: const EdgeInsets.only(left: 150.0, top: 40.0),
              child: new ElevatedButton(
                child: const Text('ADD'),
                onPressed: () {

                  LocationsAll.listobj.add(l);

                  if (key.currentState.validate()) {
                    Scaffold.of(context)
                        .showSnackBar(SnackBar(content: Text('Please wait')));
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => MyAppPage ()),
                    );
                    Houda().updateLocation();
                  }
                },
              )
          ),
        ],
      ),
    );
  }
}
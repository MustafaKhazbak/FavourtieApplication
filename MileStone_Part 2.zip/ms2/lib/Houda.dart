
import 'package:cloud_firestore/cloud_firestore.dart';
import 'data/LocationsAll.dart';


class Houda {
  final CollectionReference Aly = FirebaseFirestore.instance.collection('Aly');


  Future<void> updateLocation() {
    int i=LocationsAll.listobj.length-1;
    return
      Aly.doc((i+1).toString()).set({
        'name': LocationsAll.listobj[i].name,
        'theme': LocationsAll.listobj[i].theme,
        'description': LocationsAll.listobj[i].description,
        'imageUrl': LocationsAll.listobj[i].imageUrl,
        'locationUrl': LocationsAll.listobj[i].locationUrl,
        'id':i+1
      }
      );
    }
  }

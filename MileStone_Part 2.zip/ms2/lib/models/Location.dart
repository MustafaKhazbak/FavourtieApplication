class Location {
  int id;
  String name;
  String theme;
  String description;
  String imageUrl;
  String locationUrl;
  Location({ this.id, this.name, this.description, this.theme, this.imageUrl, this.locationUrl});
}
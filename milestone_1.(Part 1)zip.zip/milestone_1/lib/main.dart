import 'package:flutter/material.dart';
import 'package:milestone_1/models/Location.dart';
import 'package:url_launcher/url_launcher.dart';
import 'data/LocationsAll.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  // This widget is the root
  // of your application.
  @override
  Widget build(BuildContext context) {
    return new MaterialApp(
        title: "Favorite Location App",
        theme: new ThemeData(
          primarySwatch: Colors.amber,
        ),
        debugShowCheckedModeBanner: false,
        home: new MyAppPage()
    );
  }
}
class MyAppPage extends StatelessWidget {
  Location l=new Location();
  MyAppPage({this.l});
  final items = List<String>.generate(1000, (i) => "Item $i");
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => ButtonRoute()),
          );
        },
        child: const Icon(Icons.add),
        backgroundColor: Colors.amber,
      ),
      appBar: AppBar(
          title:Text("Favorite Location Application")
      ),
      body: ListView.builder(
          itemCount: LocationsAll.listobj.length,
          itemBuilder: (BuildContext context,int index){
            return Card(
              child: new InkWell(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => SecondRoute(i:index)),
                  );
                },

                child: Column(

                    children: [
                      Image.network(LocationsAll.listobj[index].imageUrl),
                      Text(LocationsAll.listobj[index].name),
                      Text(LocationsAll.listobj[index].theme,style:TextStyle(color:Colors.grey)),

                    ]
                ),
              ),
            );
          }
      ),
    );
  }
}

class SecondRoute extends StatelessWidget {
  LocationsAll location = new LocationsAll();
  int i;
  SecondRoute({this.i}){}
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: FloatingActionButton(
        child: Icon(Icons.location_on),
        onPressed: () {
          launch(LocationsAll.listobj[i].locationUrl);

        },
      ),
      appBar: AppBar(
        title: Text("Details"),
      ),
      body: SingleChildScrollView(
        child: Column(children: <Widget>[
          Padding(
            padding: const
            EdgeInsets.symmetric(vertical:5.0),
          ),
          Text(LocationsAll.listobj[i].name, style:TextStyle(fontSize:30.0,fontWeight:FontWeight.bold,
              fontStyle: FontStyle.italic,fontFamily:'sans-serif')),
          Padding(
            padding: const
            EdgeInsets.symmetric(vertical:5.0),
          ),
          Container(height: 240, width: 380,
              child: Image.network(LocationsAll.listobj[i].imageUrl)),
          Padding(
            padding: const
            EdgeInsets.symmetric(vertical:5.0),
          ),
          Text(LocationsAll.listobj[i].description, style:TextStyle(fontSize:19.0,fontFamily:'sans-serif'))


        ]

        ),

      ),
    );
  }
}

class ButtonRoute extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.amber,
        title: Text("Form"),
      ),

      body: MyFormPage(),
    );
  }
}
class MyFormPage extends StatefulWidget {
  MyFormPage({Key key, this.title,}) : super(key: key);
  final String title;
  MyFormPageState createState() {
    return MyFormPageState();

  }
}

class MyFormPageState extends State<MyFormPage> {
  int i =LocationsAll.listobj.length;
  Location l=new Location();

  final key = GlobalKey<FormState>();
  final myController = TextEditingController();
  Widget build(BuildContext context) {
    return Form(
      key: key,

      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          TextFormField(
              decoration: const InputDecoration(
                icon: const Icon(Icons.location_city),
                hintText: 'Enter location name',
                labelText: 'Location name',

              ),
              validator: (value) {
                if (value.isEmpty) {
                  return 'Please enter Location name';
                }
                else{
                  l.name =value;
                  l.id=i+1;

                }
                return null;
              }),
          TextFormField(
            decoration: const InputDecoration(
              icon: const Icon(Icons.theaters),
              hintText: 'Enter Theme',
              labelText: 'Theme',
            ),
            validator: (value) {
              if (value.isEmpty) {
                return 'Please enter theme';
              }
              else{
                l.theme=value;
              }
              return null;
            },
          ),
          TextFormField(
              decoration: const InputDecoration(
                icon: const Icon(Icons.description),
                hintText: 'Enter full description',
                labelText: 'Full description',
              ),
              validator: (value) {
                if (value.isEmpty) {
                  return 'Please enter full description';
                }
                else{
                  l.description=value;
                }
                return null;
              }),
          TextFormField(
              decoration: const InputDecoration(
                icon: const Icon(Icons.image),
                hintText: 'Enter image URL',
                labelText: 'Image URL',
              ),
              validator: (value) {
                if (value.isEmpty) {
                  return 'Please enter image URL';
                }
                else{
                  l.imageUrl=value;
                }
                return null;
              }),
          TextFormField(
              decoration: const InputDecoration(
                icon: const Icon(Icons.location_city),
                hintText: 'Enter location URL',
                labelText: 'Location URL',
              ),
              validator: (value) {
                if (value.isEmpty) {
                  return 'Please enter Location URL';
                }
                else{
                  l.locationUrl=value;
                }
                return null;
              }),

          new Container(
              padding: const EdgeInsets.only(left: 150.0, top: 40.0),
              child: new ElevatedButton(
                child: const Text('ADD'),
                onPressed: () {
                  LocationsAll.listobj.add(l);
                  if (key.currentState.validate()) {
                    Scaffold.of(context)
                        .showSnackBar(SnackBar(content: Text('Please wait')));
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => MyAppPage (l:l)),
                    );
                  }
                },
              )
          ),
        ],
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  // This widget is the root
  // of your application.
  @override
  Widget build(BuildContext context) {
    return new MaterialApp(
        title: "Favorite Location App",
        theme: new ThemeData(
            primarySwatch: Colors.amber,
        ),
        debugShowCheckedModeBanner: false,
        home: new MyAppPage()
    );
  }
}
class MyAppPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          // Add your onPressed code here!
        },
        child: const Icon(Icons.add),
        backgroundColor: Colors.amber,
      ),
      appBar: AppBar(
          title:Text("Favorite Location Application")
      ),
      body: ListView.builder(
        itemCount: 5,
        itemBuilder: (BuildContext context,int index){
            if(index == 0){
              return Card(
                child: new InkWell(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => FirstRoute()),
                    );
                  },

                child: Column(

                  children: [
                    Image.network(
                        "https://www.mazadatours.com/wp-content/uploads/2017/01/Egyptian-Museum-in-Cairo2.jpg"),
                    Text("The Egyptian Museum", style: TextStyle(fontSize: 30.0, fontWeight: FontWeight.bold)),
                    Text("Egyptian Heritage", style: TextStyle(fontSize: 20.0)),

                  ],

                ),
              ),
              );
            }
            else{
            if (index == 1) {
              return Card(
                  child: new InkWell(
                  onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => SecondRoute()),
                );
              },
                child: Column(
                  children: [
                    Image.network(
                        "https://upload.wikimedia.org/wikipedia/commons/e/e3/Kheops-Pyramid.jpg"),
                    Text("The Great Pyramid of Giza", style: TextStyle(
                        fontSize: 30.0, fontWeight: FontWeight.bold)),
                    Text("Pharaonic", style: TextStyle(fontSize: 20.0)),
                  ],

                ),
                  ),
              );
            }
            else{
              if(index == 2){
                return Card(
                    child: new InkWell(
                    onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => ThirdRoute()),
                  );
                },
                  child:Column(
                    children: [
                      Image.network( "https://www.worldatlas.com/upload/4f/c6/2f/shutterstock-397432201.jpg"),
                      Text("Abu Simbel Temples",style: TextStyle(fontSize: 30.0, fontWeight: FontWeight.bold)),
                      Text("Pharaonic",style: TextStyle(fontSize: 20.0)),
                    ],

                  ),
                    ),
                );
              }
              else{
                if (index == 3){
                  return Card(
                      child: new InkWell(
                      onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => FourthRoute()),
                    );
                  },
                    child:Column(
                      children: [
                        Image.network( "https://4.bp.blogspot.com/-6RX--BMe-PA/UHAa8fRiKaI/AAAAAAAABXA/5v9KcZ3HCvY/s1600/IMGP2321.jpg"),
                        Text("Philae",style: TextStyle(fontSize: 30.0, fontWeight: FontWeight.bold)),
                        Text("Pharaonic",style: TextStyle(fontSize: 20.0)),
                      ],

                    ),
                      ),
                  );
                }
                else{
                  return Card(
                      child: new InkWell(
                      onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => FifthRoute()),
                    );
                  },
                    child:Column(
                      children:[
                        Image.network( "https://justfunfacts.com/wp-content/uploads/2016/08/luxor-temple-colonnade.jpg"),
                        Text("Luxor Temple",style: TextStyle(fontSize: 30.0, fontWeight: FontWeight.bold)),
                        Text("Pharaonic",style: TextStyle(fontSize: 20.0)),
                      ],

                    ),
                      ),
                  );
                }
                }
              }
            }
            }
      ),
    );
  }
}
class FirstRoute extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        floatingActionButton: FloatingActionButton(
          onPressed: () {
            launch('https://www.google.com/maps/place/The+Egyptian+Museum/@30.0209745,31.1411905,13z/data=!4m8!1m2!2m1!1segyptian+museum!3m4!1s0x0:0x520da52b3a7a660f!8m2!3d30.0475784!4d31.2336159');
          },
          child: const Icon(Icons.navigation),
          backgroundColor: Colors.amber,
        ),
      appBar: AppBar(
        backgroundColor: Colors.amber,
        title: Text("Details"),
      ),

      body: Card(
            clipBehavior: Clip.antiAliasWithSaveLayer,
            child: Column(
              children: [
                Text("The Egyptian Museum",style: TextStyle(fontSize: 30.0, fontWeight: FontWeight.bold)),
                Image.network(
                  "https://www.mazadatours.com/wp-content/uploads/2017/01/Egyptian-Museum-in-Cairo2.jpg",
                  fit: BoxFit.fill,
                ),
                Text("The Museum of Egyptian Antiquities, known commonly as the Egyptian Museum or Museum of Cairo, in Cairo, Egypt, is home to an extensive collection of ancient Egyptian antiquities. It has 120,000 items, with a representative amount on display and the remainder in storerooms. Built in 1901 by the Italian construction company, Garozzo-Zaffarani, to a design by the French architect Marcel Dourgnon, the edifice is one of the largest museums in the region. As of March 2019, the museum was open to the public. In 2021, the museum is due to be superseded by the new Grand Egyptian Museum at Giza.",style: TextStyle(fontSize: 20.0)),
              ],
            ),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10.0),
            ),
            elevation: 5,
            margin: EdgeInsets.all(10),
          )
      );
  }
}
class SecondRoute extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        floatingActionButton: FloatingActionButton(
          onPressed: () {
            launch("https://www.google.com/maps/place/The+Great+Pyramid+of+Giza/@29.9792391,31.1320132,17z/data=!3m1!4b1!4m5!3m4!1s0x14584587ac8f291b:0x810c2f3fa2a52424!8m2!3d29.9792345!4d31.1342019");
          },
          child: const Icon(Icons.navigation),
          backgroundColor: Colors.amber,
        ),
        appBar: AppBar(
          backgroundColor: Colors.amber,
          title: Text("Details"),
        ),

        body: Card(
          clipBehavior: Clip.antiAliasWithSaveLayer,
          child: Column(
            children: [
              Text("The Great Pyramid of Giza",style: TextStyle(fontSize: 30.0, fontWeight: FontWeight.bold)),
              Image.network(
                "https://upload.wikimedia.org/wikipedia/commons/e/e3/Kheops-Pyramid.jpg",
                fit: BoxFit.fill,
              ),
              Text("The Great Pyramid of Giza (also known as the Pyramid of Khufu or the Pyramid of Cheops) is the oldest and largest of the three pyramids in the Giza pyramid complex bordering present-day Giza in Greater Cairo, Egypt. It is the oldest of the Seven Wonders of the Ancient World, and the only one to remain largely intact.",style: TextStyle(fontSize: 25.0)),
                ],
          ),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10.0),
          ),
          elevation: 5,
          margin: EdgeInsets.all(10),
        )
    );
  }
}
class ThirdRoute extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        floatingActionButton: FloatingActionButton(
          onPressed: () {
            launch("https://www.google.com/maps/place/Abu+Simbel+Temples/@22.3372368,31.6236103,17z/data=!3m1!4b1!4m5!3m4!1s0x143aa988b126055b:0xa7d3cc6618f898d2!8m2!3d22.3372319!4d31.625799");
          },
          child: const Icon(Icons.navigation),
          backgroundColor: Colors.amber,
        ),
        appBar: AppBar(
          backgroundColor: Colors.amber,
          title: Text("Details"),
        ),

        body: Card(
          clipBehavior: Clip.antiAliasWithSaveLayer,
          child: Column(
            children: [
              Text("Abu Simbel temples",style: TextStyle(fontSize: 30.0, fontWeight: FontWeight.bold)),
              Image.network(
                "https://www.worldatlas.com/upload/4f/c6/2f/shutterstock-397432201.jpg",
                fit: BoxFit.fill,
              ),
              Text("The Abu Simbel temples are two massive rock-cut temples at Abu Simbel (Arabic: أبو سمبل‎), a village in Aswan Governorate, Upper Egypt, near the border with Sudan. They are situated on the western bank of Lake Nasser, about 230 km (140 mi) southwest of Aswan (about 300 km (190 mi) by road). The complex is part of the UNESCO World Heritage Site known as the 'Nubian Monuments', which run from Abu Simbel downriver to Philae (near Aswan). The twin temples were originally carved out of the mountainside in the 13th century BC, during the 19th Dynasty reign of the Pharaoh Ramesses II. They serve as a lasting monument to the king Ramesses II. His wife Nefertari and children can be seen in smaller figures by his feet, considered to be of lesser importance and were not given the same position of scale. This commemorates his victory at the Battle of Kadesh. Their huge external rock relief figures have become iconic.",style: TextStyle(fontSize: 17.0)),
                ],
          ),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10.0),
          ),
          elevation: 5,
          margin: EdgeInsets.all(10),
        )
    );
  }
}
class FourthRoute extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        floatingActionButton: FloatingActionButton(
          onPressed: () {
            launch("https://www.google.com/maps/place/Philae/@24.0134126,32.8678317,15z/data=!3m1!4b1!4m5!3m4!1s0x143662bfbe299cbf:0xd571ef8bf3780147!8m2!3d24.01266!4d32.8775404");
          },
          child: const Icon(Icons.navigation),
          backgroundColor: Colors.amber,
        ),
        appBar: AppBar(
          backgroundColor: Colors.amber,
          title: Text("Details"),
        ),

        body: Card(
          clipBehavior: Clip.antiAliasWithSaveLayer,
          child: Column(
            children: [
              Text("Philae",style: TextStyle(fontSize: 30.0, fontWeight: FontWeight.bold)),
              Image.network(
                "https://4.bp.blogspot.com/-6RX--BMe-PA/UHAa8fRiKaI/AAAAAAAABXA/5v9KcZ3HCvY/s1600/IMGP2321.jpg",
                fit: BoxFit.fill,
              ),
              Text("Philae is an island in the reservoir of the Aswan Low Dam, downstream of the Aswan Dam and Lake Nasser, Egypt. Philae was originally located near the expansive First Cataract of the Nile in Upper Egypt and was the site of an Egyptian temple complex. These rapids and the surrounding area have been variously flooded since the initial construction of the Aswan Low Dam in 1902.[3] The temple complex was dismantled and moved to nearby Agilkia Island as part of the UNESCO Nubia Campaign project, protecting this and other complexes before the 1970 completion of the Aswan High Dam.[4] The hieroglyphic reliefs of the temple complex are being studied and published by the Philae Temple Text Project of the Austrian Academy of Sciences, Vienna (Institute OREA).",style: TextStyle(fontSize: 17.0)),
                ],
          ),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10.0),
          ),
          elevation: 5,
          margin: EdgeInsets.all(10),
        )
    );
  }
}
class FifthRoute extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        floatingActionButton: FloatingActionButton(
          onPressed: () {
            launch("https://www.google.com/maps/place/Luxor+Temple/@25.6995068,32.6368622,17z/data=!3m1!4b1!4m5!3m4!1s0x144915c41edadf61:0x7693895c346c7d81!8m2!3d25.699502!4d32.6390509");
          },
          child: const Icon(Icons.navigation),
          backgroundColor: Colors.amber,
        ),
        appBar: AppBar(
          backgroundColor: Colors.amber,
          title: Text("Details"),
        ),

        body: Card(
          clipBehavior: Clip.antiAliasWithSaveLayer,
          child: Column(
            children: [
              Text("Luxor Temple",style: TextStyle(fontSize: 30.0, fontWeight: FontWeight.bold)),
              Image.network(
                "https://justfunfacts.com/wp-content/uploads/2016/08/luxor-temple-colonnade.jpg",
                fit: BoxFit.fill,
              ),
              Text("The Luxor Temple (Arabic: معبد الاقصر) is a large Ancient Egyptian temple complex located on the east bank of the Nile River in the city today known as Luxor (ancient Thebes) and was constructed approximately 1400 BCE. In the Egyptian language it is known as ipet resyt, 'the southern sanctuary'. In Luxor there are several great temples on the east and west banks. Four of the major mortuary temples visited by early travelers include the Temple of Seti I at Gurnah, the Temple of Hatshepsut at Deir el Bahri, the Temple of Ramesses II (i.e., Ramesseum), and the Temple of Ramesses III at Medinet Habu. The two primary cults' temples on the east bank are known as the Karnak and Luxor.[1] Unlike the other temples in Thebes, Luxor temple is not dedicated to a cult god or a deified version of the pharaoh in death. Instead, Luxor temple is dedicated to the rejuvenation of kingship; it may have been where many of the pharaohs of Egypt were crowned in reality or conceptually (as in the case of Alexander the Great, who claimed he was crowned at Luxor but may never have traveled south of Memphis, near modern Cairo).",style: TextStyle(fontSize: 15.0)),

                ],
          ),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10.0),
          ),
          elevation: 5,
          margin: EdgeInsets.all(10),

        )
    );
  }
}
